package util;

import java.util.HashMap;
import java.util.Map;

public class MapAction {
	private HashMap<String, Object> mapVo;
	private Map<Object, Object> objMap;
	
	public Map<Object, Object> getObjMap() {
		return objMap;
	}

	public void setObjMap(Map<Object, Object> objMap) {
		this.objMap = objMap;
	}

	public HashMap<String, Object> getMapVo() {
		return mapVo;
	}

	public void setMapVo(HashMap<String, Object> mapVo) {
		this.mapVo = mapVo;
	}

}
